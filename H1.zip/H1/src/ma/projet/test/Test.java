package ma.projet.test;

import ma.projet.entities.Produit;
import ma.projet.service.ProduitService;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Test {

    public static void main(String[] args) {
        ProduitService produitService = new ProduitService();

        // 1. Créer cinq produits
        creerProduits(produitService);

        // 2. Afficher la liste des produits
        afficherProduits(produitService.findAll());

        // 3. Afficher les informations du produit dont id = 2
        afficherProduitById(produitService, 2);

        // 4. Supprimer le produit dont id = 3
        supprimerProduitById(produitService, 3);

        // 5. Modifier les informations du produit dont id = 1
        modifierProduitById(produitService, 1);

        // 6. Afficher la liste des produits dont le prix est supérieur à 100 DH
        afficherProduitsSupérieursA(produitService.findAll(), 100);

        // 7. Afficher la liste des produits commandés entre deux dates lues au clavier
        afficherProduitsEntreDates(produitService.findAll());
    }

    // Méthode pour créer des produits
    private static void creerProduits(ProduitService produitService) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            produitService.create(new Produit(0, "Marque1", "Ref1", sdf.parse("01/01/2024"), 150.0, "Produit 1"));
            produitService.create(new Produit(0, "Marque2", "Ref2", sdf.parse("15/06/2024"), 50.0, "Produit 2"));
            produitService.create(new Produit(0, "Marque3", "Ref3", sdf.parse("30/09/2024"), 200.0, "Produit 3"));
            produitService.create(new Produit(0, "Marque4", "Ref4", sdf.parse("10/11/2024"), 120.0, "Produit 4"));
            produitService.create(new Produit(0, "Marque5", "Ref5", sdf.parse("20/12/2024"), 80.0, "Produit 5"));
        } catch (ParseException e) {
            System.out.println("Erreur lors du parsing des dates : " + e.getMessage());
        }
    }

    // Méthode pour afficher la liste des produits
    private static void afficherProduits(List<Produit> produits) {
        System.out.println("Liste des produits :");
        produits.forEach(produit -> System.out.println("Produit{id=" + produit.getId() +
                ", marque='" + produit.getMarque() + "', prix=" + produit.getPrix() + ", designation='" + produit.getDesignation() + "'}"));
    }

    // Méthode pour afficher un produit par ID
    private static void afficherProduitById(ProduitService produitService, int id) {
        Produit produit = produitService.findById(id);
        if (produit != null) {
            System.out.println("\nInformations du produit dont id = " + id + ":");
            System.out.println("Produit{id=" + produit.getId() + ", marque='" + produit.getMarque() +
                    "', ref='" + produit.getRef() + "', dateAchat='" + produit.getDateAchat() +
                    "', prix=" + produit.getPrix() + ", designation='" + produit.getDesignation() + "'}");
        } else {
            System.out.println("Produit avec ID = " + id + " non trouvé.");
        }
    }

    // Méthode pour supprimer un produit par ID
    private static void supprimerProduitById(ProduitService produitService, int id) {
        Produit produit = produitService.findById(id);
        if (produit != null) {
            produitService.delete(produit);
            System.out.println("\nProduit avec ID = " + id + " supprimé.");
        } else {
            System.out.println("Produit avec ID = " + id + " non trouvé.");
        }
    }

    // Méthode pour modifier un produit par ID
    private static void modifierProduitById(ProduitService produitService, int id) {
        Produit produit = produitService.findById(id);
        if (produit != null) {
            produit.setMarque("NouvelleMarque");
            produit.setPrix(180.0);
            produitService.update(produit);
            System.out.println("\nProduit avec ID = " + id + " modifié.");
        } else {
            System.out.println("Produit avec ID = " + id + " non trouvé.");
        }
    }

    // Méthode pour afficher les produits avec un prix supérieur à un certain montant
    private static void afficherProduitsSupérieursA(List<Produit> produits, double prixMin) {
        System.out.println("\nProduits avec prix supérieur à " + prixMin + " DH :");
        produits.stream()
                .filter(produit -> produit.getPrix() > prixMin)
                .forEach(produit -> System.out.println("Produit{id=" + produit.getId() + ", marque='" 
                        + produit.getMarque() + "', prix=" + produit.getPrix() + ", designation='" + produit.getDesignation() + "'}"));
    }

    // Méthode pour afficher les produits entre deux dates
    private static void afficherProduitsEntreDates(List<Produit> produits) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        try {
            System.out.print("\nEntrez la première date (dd/MM/yyyy) : ");
            Date date1 = sdf.parse(scanner.nextLine());

            System.out.print("Entrez la deuxième date (dd/MM/yyyy) : ");
            Date date2 = sdf.parse(scanner.nextLine());

            System.out.println("\nProduits commandés entre " + sdf.format(date1) + " et " + sdf.format(date2) + " :");
            produits.stream()
                    .filter(produit -> produit.getDateAchat().after(date1) && produit.getDateAchat().before(date2))
                    .forEach(produit -> System.out.println("Produit{id=" + produit.getId() + ", marque='" 
                     + produit.getMarque() + "', dateAchat='" + sdf.format(produit.getDateAchat()) + 
                       "', prix=" + produit.getPrix() + ", designation='" + produit.getDesignation() + "'}"));
        } catch (ParseException e) {
            System.out.println("Erreur de format de date.");
        } finally {
            scanner.close(); 
        }
    }
}
